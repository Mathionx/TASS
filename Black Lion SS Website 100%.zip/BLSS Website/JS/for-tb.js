function verifyTeacher() {
  const correctID = "T12345"; // Set your actual teacher ID here
  const enteredID = document.getElementById("teacher-id-input").value;
  
  if (enteredID === correctID) {
    document.getElementById("book-container").style.display = "block";
    document.querySelector(".teacher-access").style.display = "none"; // Hide input section
  } else if (enteredID === "") {
    alert("Please enter your Teacher ID.");
  } else {
    alert("Access Denied. Invalid Teacher ID.");
  }
}