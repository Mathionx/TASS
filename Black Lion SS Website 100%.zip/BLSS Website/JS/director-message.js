function toggleMessage() {
    const fullMessage = document.getElementById("message-full");
    const preview = document.getElementById("message-preview");
    const button = document.getElementById("see-more-btn");

    if (fullMessage.style.display === "none") {
      fullMessage.style.display = "block";
      preview.style.display = "none";
      button.textContent = "See Less";
    } else {
      fullMessage.style.display = "none";
      preview.style.display = "block";
      button.textContent = "See More";
    }
  }