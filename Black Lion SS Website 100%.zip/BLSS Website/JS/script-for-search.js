function searchBooks() {
    let searchInput = document.getElementById("search-input").value.toLowerCase();
    let books = document.querySelectorAll(".book-s");
    
    books.forEach(function(book) {
      let title = book.getAttribute("data-title").toLowerCase();
      if (title.includes(searchInput)) {
        book.style.display = "block";  // Show the book
      } else {
        book.style.display = "none";  // Hide the book
      }
    });
  }
  